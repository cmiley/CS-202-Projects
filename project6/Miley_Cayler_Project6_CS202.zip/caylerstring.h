#include<iostream>

using namespace std;

/******************************************************/
//FUNCTION PROTOTYPES
/******************************************************/

void strcopy( char* destptr, char* sourceptr );
int strcomp( char* sptr1, char* sptr2 );
int strlen( char* sptr );
void strcat( char* dest, char* first, char* second );
